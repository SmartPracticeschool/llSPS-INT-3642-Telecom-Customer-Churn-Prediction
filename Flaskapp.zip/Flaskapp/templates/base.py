<html>
<body>
<form action = "/login" method = "post">
<p> SeniorCitizen</p>
<p><input type = "text" name = "sc" /></p>
<p> Partner</p>
<p><input type = "text" name = "pa" /></p>
<p> tenure</p>
<p><input type = "text" name = "te" /></p>
<p>PhoneService</p>
<p><input type = "text" name = "ps" /></p>
<p>MultipleLines</p>
<p><input type = "text" name = "ml" /></p>
<p>InternetService</p>
<p><input type = "text" name = "Is" /></p>
<p>TechSupport</p>
<p><input type = "text" name = "ts" /></p>
<p>StreamingTV</p>
<p><input type = "text" name = "st" /></p>
<p>StreamingMovies</p>
<p><input type = "text" name = "sm" /></p>
<p>PaymentMethod</p>
<p><input type = "text" name = "pm" /></p>
<p>MonthlyCharges</p>
<p><input type = "text" name = "mc" /></p>
<p>TotalCharges</p>
<p><input type = "text" name = "tc" /></p>
<p><input type = "submit" value = "click" /> </p>
<b>{{y}}</b>
</form>
</body>
</html>

