
from flask import Flask , render_template,request
import pickle
model = pickle.load(open(r'D:\srija\Flaskapp\Churn.pkl','rb'))
app = Flask(__name__)
@app.route('/') #when the browser is routed towrads url execute below function
def y_pred():
   return render_template("index.html")
@app.route('/login',methods=["POST"])
def fun2():

   sc = request.form['sc']
   pa = request.form['pa']
   te = request.form['te']
   ps = request.form['ps']
   ml = request.form['ml']
   Is = request.form['Is']
   ts = request.form['ts']
   st = request.form['st']
   sm = request.form['sm']
   pm = request.form['Payment Method']
   if(pm=='Bank transfer (automatic)'):
       s1,s2,s3,s4=1,0,0,0
   if(pm=='Credit card (automatic)'):
       s1,s2,s3,s4=0,1,0,0
   if(pm=='Electronic check'):
       s1,s2,s3,s4=0,0,1,0
   if(pm=='Mailed check'):
       s1,s2,s3,s4=0,0,0,1
      
   mc = request.form['mc']
   tc = request.form['tc']
   data = [[int(sc),int(pa),int(te),int(ps),int(ml),int(Is),int(ts),int(st),int(sm),int(s1),int(s2),int(s3),int(s4),str(mc),str(tc)]]
   pred=model.predict(data)
   if(pred==[0]):
       ans = "The customer will exit"
   else:
       ans = "The customer Remains stay"
         
   return render_template("index.html", pred= 'Prediction {}'.format(ans))
if __name__ == '__main__':
   app.run(debug = True)